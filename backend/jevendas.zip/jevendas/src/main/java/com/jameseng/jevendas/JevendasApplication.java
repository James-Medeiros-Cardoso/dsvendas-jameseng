package com.jameseng.jevendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JevendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(JevendasApplication.class, args);
	}

}
